# Getting Started with Nodejs App
* cd backend
* npm install
* npm install -g nodemon
* nodemon
